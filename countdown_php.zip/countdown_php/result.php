<?php


echo 'result';


?>