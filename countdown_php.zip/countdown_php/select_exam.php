<?php
session_start();
?>
<?php
include "connection.php";

?>


<?php
    $res=mysqli_query($link,"select * from table1");
    while($row=mysqli_fetch_array($res))
    {
    ?>
<input type="button" value="<?php echo $row["category"]; ?>" onclick="set_exam_type_session(this.value)">
<?php } ?>

<script type="text/javascript">
function set_exam_type_session(exam_category) {
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
        if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
            window.location = "dashboard.php";
        }
    };
    xmlhttp.open("GET", "set_exam_type_session.php?exam_category=" + exam_category, true);
    xmlhttp.send(null);
}
</script>